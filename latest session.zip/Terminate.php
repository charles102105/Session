<?php
ob_start();
session_start(); 


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
    <style>
       
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg,rgb(148, 162, 224) 0%,rgb(163, 156, 170) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            flex-direction: column; 
        }

        .logo-container {
            margin-bottom: 20px; 
            text-align: center; 
        }

        .logo-container img {
            max-width: 150px; 
            height: auto;
            border-radius: 10px; 
        }

        
        .terminate-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
        }

        .decorative-line {
            height: 4px;
            background: linear-gradient(135deg, #FF6B6B 0%, #FF2E2E 100%); 
            border-radius: 2px;
            margin-bottom: 30px; 
        }

        h1 {
            color: #d9534f;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 15px; 
        }

        p {
            color: #666;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 25px; 
        }

        .button-link {
            display: inline-block;
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); /* Original gradient for primary action */
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-decoration: none; 
        }

        .button-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }

        .button-link:active {
            transform: translateY(0);
        }

        @media (max-width: 480px) {
            .terminate-container {
                padding: 30px 25px;
                margin: 10px;
            }
            
            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="logo-container">
        <img src="images/logocj.png" alt="Company Logo">
    </div>
    <div class="terminate-container">
        <div class="decorative-line"></div>
        <h1>Access Denied!</h1>
        <p>You tried to access a page that requires you to be logged in.</p>
        <p>Please log in first to continue.</p>
        <p>
            <a href="login.php" class="button-link">Go to Login Page</a>
        </p>
    </div>
</body>
</html>