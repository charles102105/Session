<?php
ob_start();
session_start();


$username = '';
if (isset($_SESSION['username'])) {
    $username = htmlspecialchars($_SESSION['username']);
}


$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg,rgb(148, 162, 224) 0%,rgb(163, 156, 170) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            text-align: center;
            color: white;
            flex-direction: column;
        }

        .logout-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #333;
        }

        .decorative-line {
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 2px;
            margin-bottom: 30px;
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 15px;
            color: #333;
        }

        p {
            font-size: 1.2em;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-left-color: #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto 0;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 480px) {
            .logout-container {
                padding: 30px 25px;
                margin: 10px;
            }
            h1 {
                font-size: 2em;
            }
            p {
                font-size: 1em;
            }
        }
    </style>
    <meta http-equiv="refresh" content="3;url=login.php"> </head>
<body>
    <div class="logout-container">
        <div class="decorative-line"></div>
        <h1>Goodbye!</h1>
        <?php if (!empty($username)): ?>
            <p>Thank you for answering the quiz, <?php echo $username; ?>!</p>
        <?php else: ?>
            <p>Thank you for answering the quiz!</p>
        <?php endif; ?>
        <p>You are being logged out and redirected to the login page...</p>
        <div class="spinner"></div>
    </div>
</body>
</html>
<?php ob_end_flush(); ?>